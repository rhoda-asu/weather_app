import requests
from django.shortcuts import render

def home(request):
    weather_data = None
    error_message = None

    if request.method == "POST":
        location = request.POST.get('location')
        api_key = 'gfh6MjqvoDt0xyI4LGjCwtcx4LTBxHSQ'
        url = f'https://api.tomorrow.io/v4/weather/forecast?location={location}&apikey={api_key}'
        response = requests.get(url)
        
        # Log the response for debugging
        print("API Response: ", response.json())  # inspect the response format
        
        if response.status_code == 200:
            data = response.json()
            current_weather = data.get('timelines', {}).get('minutely', [{}])[0].get('values', {})
            
            # Extract values, ensuring the data exists
            weather_data = {
                'temperature': current_weather.get('temperature', 'N/A'),
                'humidity': current_weather.get('humidity', 'N/A'),
                'windspeed': current_weather.get('windSpeed', 'N/A'),
                'precipitation': current_weather.get('precipitation', 'N/A')
            }
        else:
            error_message = "Error fetching weather data"
    
    return render(request, 'weather/home.html', {
        'weather_data': weather_data,
        'error_message': error_message
    })
